const DIFFICULTY = 6;
const MINE_RATE = 5000;
const INITIAL_BALANCE = 500;
const MINING_REWARDS = 50;

module.exports = {
    DIFFICULTY,
    MINE_RATE,
    INITIAL_BALANCE,
    MINING_REWARDS
}; //ES6 distruction syntax used